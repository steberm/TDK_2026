clc

flagWrite = 1;
flagScale = 0;
k=4;
admissablePhysName = "Admissible";
newDir = "C:\__BME\__Dawn Raider\plasma\GetDP\";
newFileName = "iter3D.msh";

function R = Rz(alpha)
    R = [cosd(alpha) -sind(alpha) 0;
         sind(alpha)  cosd(alpha) 0;
         0            0           1];
end


%finding the the Admissable physical tag
for i=1:numPhysical
    if strcmp(physicalNames(i).name, admissablePhysName)
        admisPhysicalTag = physicalNames(i).tag;
    end
end

%finding the the admissable volume enity
for i=1:numVent
    if volumeEntities(i).physicalTags(1)==admisPhysicalTag(1)
        admisVolEntTag = volumeEntities(i).tag;
    end
end

admisTets = zeros(size(allTets/2,1),5);
TetsCoords = zeros(size(allTets/2,1),3);
anchor = 1;
for i=1:size(allTets,1) %entDim entID id n1 n2 n3 n4
    if allTets(i,2)==admisVolEntTag && allTets(i,1)==3
        admisTets(anchor,:) = allTets(i,3:7);

        x=zeros(4,1);
        y=zeros(4,1);
        z=zeros(4,1);

        for j=1:4
            n = allNode2idx(admisTets(anchor,j+1)); %node index
            x(j) = allNodes(n,4);
            y(j) = allNodes(n,5);
            z(j) = allNodes(n,6);
        end
        
        TetsCoords(anchor,1) = sum(x)/4;
        TetsCoords(anchor,2) = sum(y)/4;
        TetsCoords(anchor,3) = sum(z)/4;
        anchor = anchor+1;
    end
end
%finished all volume elements and coords
admisTets(anchor:end,:)=[]; % id n1 n2 n3 n4
TetsCoords(anchor:end,:)=[]; %x y z

alpha = atan2d(TetsCoords(:,2), TetsCoords(:,1))-avgPhi;

tet2surf=zeros(length(TetsCoords),3);

for i = 1:length(TetsCoords)
    tet2surf(i,:) = (Rz(-alpha(i)) * TetsCoords(i,:)')';
end

%Scaling the deg2 surface to match the 3d mesh
minDeg2x = min(prismCoordJ(:,1));
minDeg2y = min(prismCoordJ(:,2));
minDeg2z = min(prismCoordJ(:,3));

maxDeg2x = max(prismCoordJ(:,1));
maxDeg2y = max(prismCoordJ(:,2));
maxDeg2z = max(prismCoordJ(:,3));

sizeDeg2 = [maxDeg2x-minDeg2x, maxDeg2y-minDeg2y, maxDeg2z-minDeg2z]; %x y z

min3dx = min(tet2surf(:,1));
min3dy = min(tet2surf(:,2));
min3dz = min(tet2surf(:,3));

max3dx = max(tet2surf(:,1));
max3dy = max(tet2surf(:,2));
max3dz = max(tet2surf(:,3));

size3d = [max3dx-min3dx, max3dy-min3dy max3dz-min3dz]; %x y z


scale = mean(size3d ./ sizeDeg2);

centerDeg2 = [maxDeg2x+minDeg2x, maxDeg2y+minDeg2y, maxDeg2z+minDeg2z]/2;
center3d = [max3dx+min3dx, max3dy+min3dy, max3dz+min3dz]/2;

if(flagScale == 0)
    scale = 1;
    centerDeg2 = center3d;
end

deg2Coord = (prismCoordJ - centerDeg2) * scale + center3d;


tetJ = zeros(length(TetsCoords),3);
[idx, dist] = knnsearch(deg2Coord, tet2surf, 'K', k);

for i=1:length(tet2surf)
    sumw = 0;
    Jlocal = [0,0,0];
    for j = 1:k
        w = 1/dist(i,j)^2;
        Jlocal = Jlocal + prismJ(idx(i,j),:)*w;
        sumw = sumw + w;
    end
    Jlocal = Jlocal / sumw;
    Jlocal = (Rz(alpha(i))*Jlocal')';
    tetJ(i,:) = Jlocal;
end

%__________________________________________________________________________
if flagWrite
    
    copyfile(strcat(dir, filename), strcat(newDir, newFileName), 'f');

    fid = fopen( strcat(newDir, newFileName), 'a');
    
    if writeMerged
        fprintf(fid, strcat('$ElementData\n','1\n','"J_all"\n', '1\n', '0\n'));
        fprintf(fid, strcat('4\n', '0\n', '3\n', int2str(length(tetJ)+length(TFTetsGlobal)), '\n0\n'));

        for i=1:length(TFJGlobal)
            fprintf(fid, '%d %f %f %f\n', TFTetsGlobal(i), TFJGlobal(i,1), TFJGlobal(i,2), TFJGlobal(i,3));
        end

    else
        fprintf(fid, strcat('$ElementData\n','1\n','"J_Plasma"\n', '1\n', '0\n'));
        fprintf(fid, strcat('4\n', '0\n', '3\n', int2str(length(tetJ)), '\n0\n'));
    end

    for i=1:length(tetJ)
            fprintf(fid, '%d %f %f %f\n', admisTets(i), tetJ(i,1), tetJ(i,2), tetJ(i,3));
    end

    fprintf(fid, '$EndElementData\n');
    
    fclose(fid);

    disp 'Done'
    fprintf('New file with the name %s has been created\n', newFileName);

else
    disp 'Done'
    disp 'No new file was created'
end

%clearvars -except allNode2idx allNodes allTets physicalNames volumeEntities numPhysical numVent allPrismJ prismCoordJ prismJ dir filename avgPhi