clc
%This code is for the reading of the MSH4.1 file generated from the 2D
%axisymmetrical file by extrudation by 2°

%Input:
%   dir: The directory of the .msh file
%   filename: The name of the .msh file
%   JName: the name of the current density field
%Outputs: 
%   allPrismJ: entDim entId id n1 n2 n3 n4 n5 n6
%   prismCoordJ: x y z
%   prismJ: Jx Jy Jz
%__________________________________________________________________

dir2 = 'C:\__BME\__Dawn Raider\plasma\DeliverablesTask6\';
%filename2 = 'TestoniAPECFullTriangle.msh';
filename2 = 'TestoniAPECFullTriangle.msh';

JName = "J_APEC_admissible";
layerDeg = 0.5;
eps = 0.1;

%__________________________________________________________________
physicalNames2 = struct( ...
    'dim', {}, ...
    'tag', {}, ...
    'name', {} );

pointEntities2 = struct( ...
    'tag', {}, ...
    'X', {}, ...
    'Y', {}, ...
    'Z', {}, ...
    'numPhysicalTags', {}, ...
    'physicalTags', {} );

curveEntities2 = struct( ...
    'tag', {}, ...
    'minX', {}, ...
    'minY', {}, ...
    'minZ', {}, ...
    'maxX', {}, ...
    'maxY', {}, ...
    'maxZ', {}, ...
    'numPhysicalTags', {}, ...
    'physicalTags', {}, ...
    'numBoundingPoints', {}, ...
    'boundingPoints', {} );

surfaceEntities2 = struct( ...
    'tag', {}, ...
    'minX', {}, ...
    'minY', {}, ...
    'minZ', {}, ...
    'maxX', {}, ...
    'maxY', {}, ...
    'maxZ', {}, ...
    'numPhysicalTags', {}, ...
    'physicalTags', {}, ...
    'numBoundingCurves', {}, ...
    'boundingCurves', {} );

volumeEntities2 = struct( ...
    'tag', {}, ...
    'minX', {}, ...
    'minY', {}, ...
    'minZ', {}, ...
    'maxX', {}, ...
    'maxY', {}, ...
    'maxZ', {}, ...
    'numPhysicalTags', {}, ...
    'physicalTags', {}, ...
    'numBoundingSurfaces', {}, ...
    'boundingSurfaces', {} );



%Nodes beolvasása egy MSH 4.1 típusú file-ból


fid = fopen( strcat(dir2, filename2), 'r');


% Reading Physical Names
while true
    line = fgetl(fid);
    
    if ~ischar(line)      % fájl vége
        break
    end
    
    if strcmp(line, "$PhysicalNames")   % ha elérjük a keresett sort
        break
    end
end

line = fgetl(fid);
data = sscanf(line, '%f');
numPhysical2 = data(1);

for i = 1:numPhysical2

    line = strtrim(fgetl(fid));
    data = textscan(line, '%d %d %q');

    physicalNames2(i).dim  = data{1};
    physicalNames2(i).tag  = data{2};
    physicalNames2(i).name = data{3}{1};
end


% Reading Entities
while true
    line = fgetl(fid);
    
    if ~ischar(line)      % fájl vége
        break
    end
    
    if strcmp(line, "$Entities")   % ha elérjük a keresett sort
        break
    end
end


line = fgetl(fid);
data = sscanf(line, '%f');
numPent2 = data(1);
numCent2 = data(2);
numSent2 = data(3);
numVent2 = data(4);

for i = 1:numPent2

    line = fgetl(fid);
    data = sscanf(line, '%f');

    pointEntities2(i).tag = data(1);

    pointEntities2(i).X = data(2);
    pointEntities2(i).Y = data(3);
    pointEntities2(i).Z = data(4);
    
    numPhysicalTags = data(5);
    pointEntities2(i).numPhysicalTags=numPhysicalTags;

    pointEntities2(i).physicalTags = data(6 : 5 + numPhysicalTags);
end

for i = 1:numCent2

    line = fgetl(fid);
    data = sscanf(line, '%f');

    % Basic data
    curveEntities2(i).tag = data(1);

    curveEntities2(i).minX = data(2);
    curveEntities2(i).minY = data(3);
    curveEntities2(i).minZ = data(4);

    curveEntities2(i).maxX = data(5);
    curveEntities2(i).maxY = data(6);
    curveEntities2(i).maxZ = data(7);

    % Physical tags
    numPhysicalTags = data(8);
    curveEntities2(i).numPhysicalTags=numPhysicalTags;

    physStart = 9;
    physEnd   = physStart + numPhysicalTags - 1;

    curveEntities2(i).physicalTags = data(physStart : physEnd);

    % Bounding points
    numBoundingPoints = data(physEnd + 1);
    curveEntities2(i).numBoundingPoints = numBoundingPoints;
    boundStart = physEnd + 2;
    boundEnd   = boundStart + numBoundingPoints - 1;

    curveEntities2(i).boundingPoints = data(boundStart : boundEnd);
end

for i = 1:numSent2

    line = fgetl(fid);
    data = sscanf(line, '%f');

    % Basic data
    surfaceEntities2(i).tag = data(1);

    surfaceEntities2(i).minX = data(2);
    surfaceEntities2(i).minY = data(3);
    surfaceEntities2(i).minZ = data(4);

    surfaceEntities2(i).maxX = data(5);
    surfaceEntities2(i).maxY = data(6);
    surfaceEntities2(i).maxZ = data(7);

    % Physical tags
    numPhysicalTags = data(8);
    surfaceEntities2(i).numPhysicalTags=numPhysicalTags;

    physStart = 9;
    physEnd   = physStart + numPhysicalTags - 1;

    surfaceEntities2(i).physicalTags = data(physStart : physEnd);

    % Bounding curves
    numBoundingCurves = data(physEnd + 1);
    surfaceEntities2(i).numBoundingCurves = numBoundingCurves;
    boundStart = physEnd + 2;
    boundEnd   = boundStart + numBoundingCurves - 1;

    surfaceEntities2(i).boundingCurves = data(boundStart : boundEnd);
end

for i = 1:numVent2

    line = fgetl(fid);
    data = sscanf(line, '%f');

    % Basic data
    volumeEntities2(i).tag = data(1);

    volumeEntities2(i).minX = data(2);
    volumeEntities2(i).minY = data(3);
    volumeEntities2(i).minZ = data(4);

    volumeEntities2(i).maxX = data(5);
    volumeEntities2(i).maxY = data(6);
    volumeEntities2(i).maxZ = data(7);

    % Physical tags
    numPhysicalTags = data(8);
    volumeEntities2(i).numPhysicalTags=numPhysicalTags;

    physStart = 9;
    physEnd   = physStart + numPhysicalTags - 1;

    volumeEntities2(i).physicalTags = data(physStart : physEnd);

    % Bounding surfaces
    numBoundingSurfaces = data(physEnd + 1);
    volumeEntities2(i).numBoundingSurfaces = numBoundingSurfaces;

    boundStart = physEnd + 2;
    boundEnd   = boundStart + numBoundingSurfaces - 1;

    volumeEntities2(i).boundingSurfaces = data(boundStart : boundEnd);
end


% Reading Nodes
while true
    line = fgetl(fid);
    
    if ~ischar(line)      % fájl vége
        break
    end
    
    if strcmp(line, "$Nodes")   % ha elérjük a keresett sort
        break
    end
end
line = fgetl(fid);
data = sscanf(line, '%f');
numEntities = data(1);
numNodes = data(2);
maxNodeId = data(4);

allNodes2=zeros(numNodes,6); %entDim entID id x y z
allNode2idx2 = zeros(maxNodeId, 1);
anchor=1;
for i = 1:numEntities
    line = fgetl(fid);
    data = sscanf(line, '%f');
    numNodesInBlock=data(4);
    entityTag = data(2);
    entityDim = data(1);
    for j=anchor:anchor+numNodesInBlock-1 %Writing the IDs
        line = fgetl(fid);
        data = sscanf(line, '%f');
        allNodes2(j,3) = data(1);
        allNodes2(j,2) = entityTag;
        allNodes2(j,1) = entityDim;
        allNode2idx2(data(1)) = j;
    end
    for j=anchor:anchor+numNodesInBlock-1 %Writing the coords
        line = fgetl(fid);
        data = sscanf(line, '%f');
        allNodes2(j,4:6)=data(1:3);
    end
    anchor = anchor + numNodesInBlock; % Update anchor for the next block
end
nodeEntity=length( unique(allNodes2(:,1:2), 'rows'));

% Reading Elements
while true
    line = fgetl(fid);
    
    if ~ischar(line)      % fájl vége
        break
    end
    
    if strcmp(line, "$Elements")   % ha elérjük a keresett sort
        break
    end
end
line = fgetl(fid);
data = sscanf(line, '%f');
numEntities = data(1);
numElements = data(2);
elemEntity = numEntities;

allPrism=zeros(numElements,9,'uint32'); %entDim entID id n1 n2 n3 n4 n5 n6
prismCoord=zeros(numElements,3); %x y z

prisAnchor=1;

for i = 1:numEntities
    line = fgetl(fid);
    data = sscanf(line, '%f');
    numElementsInBlock=data(4);
    entityDim = data(1);
    entityTag = data(2);
    elementType = data(3);
    if elementType==6
            for j=prisAnchor:prisAnchor+numElementsInBlock-1
                line = fgetl(fid);
                data = sscanf(line, '%f');
                allPrism(j,1)=entityDim;
                allPrism(j,2)=entityTag;
                allPrism(j,3)=data(1);
                allPrism(j,4:9)=data(2:7);
                xyz = zeros(1,3);
                for nodeC = 4:9
                    xyz = xyz + allNodes2(allNode2idx2(allPrism(j,nodeC)),4:6);
                end
                prismCoord(j,:) = xyz/6;
            end
            prisAnchor = prisAnchor + numElementsInBlock; % Update anchor for the next block
    else
        for j=1:numElementsInBlock
                fgetl(fid);
        end
    end
end
allPrism(prisAnchor:end,:)=[];
prismCoord(prisAnchor:end,:)=[];

[~, ia] = unique(allPrism(:,3:9), 'rows', 'stable');

allPrism   = allPrism(ia,:);
prismCoord = prismCoord(ia,:);



% Reading ElementData



target = strcat('"', JName, '"');


while true
    line = fgetl(fid);
    if ~ischar(line)
        disp 'Current desity not found on given name'
        break;
    end
    if strcmp(strtrim(line), target)
        break;
    end
end
for i=1:5
    fgetl(fid);
end


line = fgetl(fid);
data = sscanf(line, '%f');
numJData=data(1);

fgetl(fid);

prismJ = zeros(numJData,4); %Jx Jy Jz

for i=1:numJData
    line = fgetl(fid);
    data = sscanf(line, '%f');
    prismJ(i,:) = data(1:4);
end



phi = atan2d(prismCoord(:,2), prismCoord(:,1));

deleteIdx = false(length(prismCoord),1);

for i = 1:length(prismCoord)
    if abs(phi(i) - layerDeg) > eps
        deleteIdx(i) = true;
    end
end

prismCoord(deleteIdx,:) = [];
allPrism(deleteIdx,:) = [];
phi = atan2d(prismCoord(:,2), prismCoord(:,1));
avgPhi = sum(phi)/length(phi);

fclose(fid);

%Filtering for admissible region

admissablePhysName = "Admissible";
plasmaPhysName = "Plasma";

%finding the the Admissable physical tag
for i=1:numPhysical2
    if strcmp(physicalNames2(i).name, admissablePhysName)
        admisPhysicalTag = physicalNames2(i).tag;
    end
    if strcmp(physicalNames2(i).name, plasmaPhysName)
        plasmaPhysicalTag = physicalNames2(i).tag;
    end
end

%finding the the admissable volume enity
for i=1:numVent2
    if volumeEntities2(i).physicalTags==admisPhysicalTag(1)
        admisVolEntTag = volumeEntities2(i).tag;
    end
    if volumeEntities2(i).physicalTags==plasmaPhysicalTag(1)
        plasmaVolEntTag = volumeEntities2(i).tag;
    end
end

admisPris = zeros(size(allPrism,1),1); %id
anchor = 1;
for i=1:size(allPrism,1)
    if (allPrism(i,2)==admisVolEntTag || allPrism(i,2)==plasmaVolEntTag) && allPrism(i,1)==3
        admisPris(anchor) = allPrism(i,3);

        anchor = anchor+1;
    end
end
%finished all volume elements and coords
admisPris(anchor:end)=[]; % id 


idx = ismember(allPrism(:,3), admisPris);

deleteIdx = ~idx;
prismCoord(deleteIdx,:) = [];
allPrism(deleteIdx,:) = [];

[tf, loc] = ismember(allPrism(:,3), prismJ(:,1));

allPrismJ  = allPrism(tf,:);
prismCoordJ = prismCoord(tf,:);

prismJ = prismJ(loc(tf),2:4);





fprintf('Target phi = %.1f°\n', layerDeg);
fprintf('Average phi = %.1f°\n', avgPhi);
fprintf('allPrismJ: entDim entId id n1 n2 n3 n4 n5 n6\n');
fprintf('prismCoordJ: x y z\n');
fprintf('prismJ: Jx Jy Jz\n');
fprintf('Ready to use\n');

clearvars -except allNode2idx allNodes allTets physicalNames volumeEntities numPhysical numVent allPrismJ prismCoordJ prismJ dir filename avgPhi writeMerged TFTetsGlobal TFJGlobal