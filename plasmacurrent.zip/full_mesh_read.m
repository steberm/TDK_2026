clc

clearvars -except dir copyFilename writeMerged TFTetsGlobal TFJGlobal
%This code is for the reading of the MSH4.1 file generated automatically
% by gmsh

%Input:
%   dir: The directory of the .msh file
%   filename: The name of the .msh file
%Outputs: 
%   
%__________________________________________________________________

if ~exist(dir,"var")
    dir = 'C:\__BME\__Dawn Raider\plasma\Geometry\';
end

if exist(copyFilename,"var")
    filename = copyFilename;
else
    filename = 'geo_merge_TFJ.msh';
end


maxElementLenght=10;

%__________________________________________________________________
physicalNames = struct( ...
    'dim', {}, ...
    'tag', {}, ...
    'name', {} );

pointEntities = struct( ...
    'tag', {}, ...
    'X', {}, ...
    'Y', {}, ...
    'Z', {}, ...
    'numPhysicalTags', {}, ...
    'physicalTags', {} );

curveEntities = struct( ...
    'tag', {}, ...
    'minX', {}, ...
    'minY', {}, ...
    'minZ', {}, ...
    'maxX', {}, ...
    'maxY', {}, ...
    'maxZ', {}, ...
    'numPhysicalTags', {}, ...
    'physicalTags', {}, ...
    'numBoundingPoints', {}, ...
    'boundingPoints', {} );

surfaceEntities = struct( ...
    'tag', {}, ...
    'minX', {}, ...
    'minY', {}, ...
    'minZ', {}, ...
    'maxX', {}, ...
    'maxY', {}, ...
    'maxZ', {}, ...
    'numPhysicalTags', {}, ...
    'physicalTags', {}, ...
    'numBoundingCurves', {}, ...
    'boundingCurves', {} );

volumeEntities = struct( ...
    'tag', {}, ...
    'minX', {}, ...
    'minY', {}, ...
    'minZ', {}, ...
    'maxX', {}, ...
    'maxY', {}, ...
    'maxZ', {}, ...
    'numPhysicalTags', {}, ...
    'physicalTags', {}, ...
    'numBoundingSurfaces', {}, ...
    'boundingSurfaces', {} );



%Nodes beolvasása egy MSH 4.1 típusú file-ból


fid = fopen( strcat(dir, filename), 'r');


% Reading Physical Names
while true
    line = fgetl(fid);
    
    if ~ischar(line)      % fájl vége
        break
    end
    
    if strcmp(line, "$PhysicalNames")   % ha elérjük a keresett sort
        break
    end
end

line = fgetl(fid);
data = sscanf(line, '%f');
numPhysical = data(1);

for i = 1:numPhysical

    line = strtrim(fgetl(fid));
    data = textscan(line, '%d %d %q');

    physicalNames(i).dim  = data{1};
    physicalNames(i).tag  = data{2};
    physicalNames(i).name = data{3}{1};
end


% Reading Entities
while true
    line = fgetl(fid);
    
    if ~ischar(line)      % fájl vége
        break
    end
    
    if strcmp(line, "$Entities")   % ha elérjük a keresett sort
        break
    end
end


line = fgetl(fid);
data = sscanf(line, '%f');
numPent = data(1);
numCent = data(2);
numSent = data(3);
numVent = data(4);

for i = 1:numPent

    line = fgetl(fid);
    data = sscanf(line, '%f');

    pointEntities(i).tag = data(1);

    pointEntities(i).X = data(2);
    pointEntities(i).Y = data(3);
    pointEntities(i).Z = data(4);
    
    numPhysicalTags = data(5);
    pointEntities(i).numPhysicalTags=numPhysicalTags;

    pointEntities(i).physicalTags = data(6 : 5 + numPhysicalTags);
end

for i = 1:numCent

    line = fgetl(fid);
    data = sscanf(line, '%f');

    % Basic data
    curveEntities(i).tag = data(1);

    curveEntities(i).minX = data(2);
    curveEntities(i).minY = data(3);
    curveEntities(i).minZ = data(4);

    curveEntities(i).maxX = data(5);
    curveEntities(i).maxY = data(6);
    curveEntities(i).maxZ = data(7);

    % Physical tags
    numPhysicalTags = data(8);
    curveEntities(i).numPhysicalTags=numPhysicalTags;

    physStart = 9;
    physEnd   = physStart + numPhysicalTags - 1;

    curveEntities(i).physicalTags = data(physStart : physEnd);

    % Bounding points
    numBoundingPoints = data(physEnd + 1);
    curveEntities(i).numBoundingPoints = numBoundingPoints;
    boundStart = physEnd + 2;
    boundEnd   = boundStart + numBoundingPoints - 1;

    curveEntities(i).boundingPoints = data(boundStart : boundEnd);
end

for i = 1:numSent

    line = fgetl(fid);
    data = sscanf(line, '%f');

    % Basic data
    surfaceEntities(i).tag = data(1);

    surfaceEntities(i).minX = data(2);
    surfaceEntities(i).minY = data(3);
    surfaceEntities(i).minZ = data(4);

    surfaceEntities(i).maxX = data(5);
    surfaceEntities(i).maxY = data(6);
    surfaceEntities(i).maxZ = data(7);

    % Physical tags
    numPhysicalTags = data(8);
    surfaceEntities(i).numPhysicalTags=numPhysicalTags;

    physStart = 9;
    physEnd   = physStart + numPhysicalTags - 1;

    surfaceEntities(i).physicalTags = data(physStart : physEnd);

    % Bounding curves
    numBoundingCurves = data(physEnd + 1);
    surfaceEntities(i).numBoundingCurves = numBoundingCurves;
    boundStart = physEnd + 2;
    boundEnd   = boundStart + numBoundingCurves - 1;

    surfaceEntities(i).boundingCurves = data(boundStart : boundEnd);
end

for i = 1:numVent

    line = fgetl(fid);
    data = sscanf(line, '%f');

    % Basic data
    volumeEntities(i).tag = data(1);

    volumeEntities(i).minX = data(2);
    volumeEntities(i).minY = data(3);
    volumeEntities(i).minZ = data(4);

    volumeEntities(i).maxX = data(5);
    volumeEntities(i).maxY = data(6);
    volumeEntities(i).maxZ = data(7);

    % Physical tags
    numPhysicalTags = data(8);
    volumeEntities(i).numPhysicalTags=numPhysicalTags;

    physStart = 9;
    physEnd   = physStart + numPhysicalTags - 1;

    volumeEntities(i).physicalTags = data(physStart : physEnd);

    % Bounding surfaces
    numBoundingSurfaces = data(physEnd + 1);
    volumeEntities(i).numBoundingSurfaces = numBoundingSurfaces;

    boundStart = physEnd + 2;
    boundEnd   = boundStart + numBoundingSurfaces - 1;

    volumeEntities(i).boundingSurfaces = data(boundStart : boundEnd);
end


% Reading Nodes
while true
    line = fgetl(fid);
    
    if ~ischar(line)      % fájl vége
        break
    end
    
    if strcmp(line, "$Nodes")   % ha elérjük a keresett sort
        break
    end
end
line = fgetl(fid);
data = sscanf(line, '%f');
numEntities = data(1);
numNodes = data(2);
maxNodeId = data(4);

allNodes=zeros(numNodes,6); %entDim entID id x y z
allNode2idx = zeros(maxNodeId, 1);
anchor=1;
for i = 1:numEntities
    line = fgetl(fid);
    data = sscanf(line, '%f');
    numNodesInBlock=data(4);
    entityTag = data(2);
    entityDim = data(1);
    for j=anchor:anchor+numNodesInBlock-1 %Writing the IDs
        line = fgetl(fid);
        data = sscanf(line, '%f');
        allNodes(j,3) = data(1);
        allNodes(j,2) = entityTag;
        allNodes(j,1) = entityDim;
        allNode2idx(data(1)) = j;
    end
    for j=anchor:anchor+numNodesInBlock-1 %Writing the coords
        line = fgetl(fid);
        data = sscanf(line, '%f');
        allNodes(j,4:6)=data(1:3);
    end
    anchor = anchor + numNodesInBlock; % Update anchor for the next block
end
nodeEntity=length( unique(allNodes(:,1:2), 'rows'));

% Reading Elements
while true
    line = fgetl(fid);
    
    if ~ischar(line)      % fájl vége
        break
    end
    
    if strcmp(line, "$Elements")   % ha elérjük a keresett sort
        break
    end
end
line = fgetl(fid);
data = sscanf(line, '%f');
numEntities = data(1);
numElements = data(2);
elemEntity = numEntities;
maxElementId = data(4);

allTets=zeros(numElements,7,'uint32'); %entDim entID id n1 n2 n3 n4

tetAnchor=1;

for i = 1:numEntities
    line = fgetl(fid);
    data = sscanf(line, '%f');
    numElementsInBlock=data(4);
    entityDim = data(1);
    entityTag = data(2);
    elementType = data(3);
    if numElementsInBlock~=0
        if elementType==4
            for j=tetAnchor:tetAnchor+numElementsInBlock-1
                line = fgetl(fid);
                data = sscanf(line, '%f');
                allTets(j,1)=entityDim;
                allTets(j,2)=entityTag;
                allTets(j,3)=data(1);
                allTets(j,4:7)=data(2:5);
            end
            tetAnchor = tetAnchor + numElementsInBlock; % Update anchor for the next block
        else
            for j=1:numElementsInBlock
                fgetl(fid);
            end
        end
    end
end
allTets(tetAnchor:end,:)=[];

fclose(fid);

disp 'Done'

clearvars -except allNode2idx allNodes allTets physicalNames volumeEntities numPhysical numVent dir filename writeMerged TFTetsGlobal TFJGlobal