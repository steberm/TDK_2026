//Geometry parameters
BndRadius = 2.5e4;
eps = 0*Pi/180;
alpha = 2*Pi/9-eps;
//Mesh parameters
mshSize = 60;//70->700k, 60->950k, 50->1.5m 40->2.6m 30->5m 25->8.1m
mshScale = Sprintf("%g",mshSize*1e-3); 
a = "4"; //Mesh size in the admissible region
v = "2"; //Mesh size in the vacuum vessel
c = "5"; //Mesh size in the coils
M = "80"; //Mesh size on the edge of the computational region
d = "0.2"; //Distance of support region change
D = Sprintf("%g",BndRadius*1e-3 - 10) ;
