Include "model_params.pro";

Group{
    TF = Region[{101, 102}]; // TF coils
    VacuumVessel = Region[{201}]; // Vacuum Vessel region

    CS1 = Region[301];// CS coils
    CS2 = Region[302];
    CS3 = Region[303];
    CS4 = Region[304];
    CS5 = Region[305];
    CS6 = Region[306];

    PF1 = Region[401];// PF coils
    PF2 = Region[402];
    PF3 = Region[403];
    PF4 = Region[404];
    PF5 = Region[405];
    PF6 = Region[406];

    AxiSymCoil = Region[{301, 302, 303, 304, 305, 306, 401, 402, 403, 404, 405, 406}];

    ImportRegion = Region[{101, 102, 501}];

    CurrentRegion = Region[{301, 302, 303, 304, 305, 306, 401, 402, 403, 404, 405, 406, 101, 102, 501}];  

    Admissible = Region[501]; // Admissible region

    Air = Region[601]; // Region surrounding the model

    RegionComp = Region[701]; // full computational domain
 
    //boundaries
    BndrComp = Region[1301];  // Boundary of RegionComp
    PerBndr1 = Region[1101]; // Cross section Phi=0°
    PerBndr2 = Region[1102]; // Cross section Phi=40°
    BndrAdmis = Region[1401];  // Boundary of the Admissible region
}



Function {

    //JTF = 9.11MA
    Dir = "res/";
    nu[RegionComp]  = 1. / (4.0e-7*Pi);

    jCoil[CS1] = -0.3097784174E+07;
    jCoil[CS2] = -0.2601408664E+07;
    jCoil[CS3] = -0.1336949257E+08;
    jCoil[CS4] = -0.1336949257E+08;
    jCoil[CS5] = -0.6617269036E+07;
    jCoil[CS6] =  0.3406765719E+07;

    jCoil[PF1] =  0.6074159956E+07;
    jCoil[PF2] = -0.6918934272E+07;
    jCoil[PF3] = -0.8773943136E+07;
    jCoil[PF4] = -0.7876996373E+07;
    jCoil[PF5] = -0.1010181615E+08;
    jCoil[PF6] =  0.9811811415E+07;

    CurrentDensity[ImportRegion] = VectorField[XYZ[]];
    CurrentDensity[AxiSymCoil]=jCoil[] * Vector[ -Sin[Atan2[Y[], X[]]#1] ,Cos[#1] , 0];

   

    RotAlpha=alpha;
    Khi_ampl = 1;
    khi_initial[RegionComp] =Khi_ampl*Atan2[Y[], X[]];
}
    
Jacobian {
    { Name Vol ;
        Case { 
            { Region All ; Jacobian Vol ; }
        }
    }
    { Name Sur ;
        Case { 
            { Region All ; Jacobian Sur ; }
        }
    }
}
Integration {
    { Name GaussInt ;
        Case {{
            Type Gauss ;
            Case {
                { GeoElement Line        ; NumberOfPoints  4 ; }
                { GeoElement Triangle    ; NumberOfPoints  4 ; }
                { GeoElement Quadrangle  ; NumberOfPoints  4 ; }
                { GeoElement Tetrahedron ; NumberOfPoints  4 ; }
            }
        }}
    }
}

Constraint {
    { Name DirHom ;
        Case {
          { Region BndrComp ; Type Assign  ; Value 0. ; } // Axn=0 on the entire boundary of RegionComp. This sets Bn=0 everywhere on BndrComp
        }
    }
    { Name Khi_init ;
        Case {
          { Region RegionComp ; Type Init  ; Value khi_initial[] ; }  // 
        }
    }
    { Name Per ;
        Case {
          { Region PerBndr2; Type Link; RegionRef PerBndr1;
            Coefficient 1; Function Vector[X[]*Cos[RotAlpha] + Y[]*Sin[RotAlpha], -1*X[]*Sin[RotAlpha] + Y[]*Cos[RotAlpha], Z[]]; } 
        }
    }
    { Name GaugeT ; Type Assign ;
        Case {
            // { Region RegionComp ; SubRegion Region [{PerBndr1,Bndr}]; Value 0. ; }
            // { Region RegionComp ; SubRegion Bndr; Value 0. ; }
            { Region RegionComp ; Value 0. ; }
        }
    }
    { Name GaugeA ; Type Assign ;
        Case {
            // { Region RegionComp ; SubRegion Region [{PerBndr1,Bndr}]; Value 0. ; }
            { Region RegionComp ; SubRegion BndrComp; Value 0. ; }
            // { Region RegionComp ; Value 0. ; }
        }
    }
}
FunctionSpace {
    { Name Hcurl_T ; Type Form1 ;
        BasisFunction {
        { Name se ; NameOfCoef te ; Function BF_Edge ;
            Support Region[{RegionComp, PerBndr1, PerBndr2, CurrentRegion}] ; Entity EdgesOf[ All ] ; }  // Additional regions are to be added if they are used during postprocessing
        }
        // Constraint {
            // { NameOfCoef te  ; EntityType EdgesOf ; NameOfConstraint Per ; }
            // { NameOfCoef te  ; EntityType EdgesOfTreeIn ;  NameOfConstraint GaugeT ; }
        // }
    }
    { Name Hcurl_A ; Type Form1 ;
        BasisFunction {
        { Name se ; NameOfCoef ae ; Function BF_Edge ;
            Support Region[{RegionComp, BndrComp, PerBndr1, PerBndr2}] ; Entity EdgesOf[ All ] ; } // Additional regions are to be added if they are used during postprocessing
        }
        Constraint {
            { NameOfCoef ae  ; EntityType EdgesOf ; NameOfConstraint DirHom; }
            { NameOfCoef ae  ; EntityType EdgesOf ; NameOfConstraint Per ; }
            // { NameOfCoef ae  ; EntityType EdgesOfTreeIn ; EntitySubType StartingOn ;
            //     NameOfConstraint GaugeA ; }
        }
    }

    { Name Hregion_khi_3D ; Type Form0 ;
        BasisFunction {
        { Name se ; NameOfCoef khie ; Function BF_Node ;
            Support Region[{RegionComp}] ; Entity NodesOf[ All ] ; }
        }
        Constraint {
            { NameOfCoef khie  ; EntityType NodesOf ; NameOfConstraint Khi_init ; }
            { NameOfCoef khie  ; EntityType NodesOf ; NameOfConstraint Per ; }
        }
    }

    { Name Hregion_psi_3D ; Type Form0 ;
        BasisFunction {
        { Name se ; NameOfCoef psie ; Function BF_Node ;
            Support Region[{RegionComp}] ; Entity NodesOf[ All ] ; }
        }
        Constraint {
            { NameOfCoef psie  ; EntityType NodesOf ; NameOfConstraint Per ; }
        }
    }

}
    Formulation {
        //Projection of T from the given current densities
        { Name T_projection ; Type FemEquation ;
            Quantity {
                { Name T  ; Type Local ; NameOfSpace Hcurl_T ; }
            }
            Equation {
                Galerkin { [ Dof{d T} , {d T} ] ;
                    In RegionComp ; Jacobian Vol ; Integration GaussInt ; }
                Galerkin { [ - CurrentDensity[] , {d T} ] ;
                    In CurrentRegion ; Jacobian Vol ; Integration GaussInt ; }  // computes T in RegionComp for it to be used as the excitation of the magnetic equation
            }
        }
        //Calculation of magnetic vector potential from the previously calculated T current vector potential
        { Name A_formalism ; Type FemEquation ;
            Quantity {
                { Name A  ; Type Local ; NameOfSpace Hcurl_A ; }
                { Name T  ; Type Local ; NameOfSpace Hcurl_T ; }
            }
            Equation {
                Galerkin { [ nu[] * Dof{d A} , {d A} ] ;
                    In RegionComp ; Jacobian Vol ; Integration GaussInt ; }
                Galerkin { [ - {d T} , {A} ] ;
                    In RegionComp ; Jacobian Vol ; Integration GaussInt ; }  // computes A in RegionComp, magnetostatic field excited by static current field in conductor
            }
        }

        { Name Psi_formalism ; Type FemEquation ;
            Quantity {
                { Name A  ; Type Local ; NameOfSpace Hcurl_A ; }
                { Name Khi  ; Type Local ; NameOfSpace Hregion_khi_3D ; }
                { Name Psi  ; Type Local ; NameOfSpace Hregion_psi_3D ; }
            }
            Equation {
                Galerkin { [ ({d Khi} /\ (Dof{d Psi} /\ {d Khi})) , {d Psi} ]  ;
                In RegionComp ; Jacobian Vol ; Integration GaussInt ; }
                Galerkin { [  -({d Khi} /\ {d A}), {d Psi} ] ;
                In RegionComp ; Jacobian Vol ; Integration GaussInt ; }  // computes Psi(n+1) from  from Khi(n) and A
            }
        }
        
        { Name Khi_formalism ; Type FemEquation ;
            Quantity {
                { Name A  ; Type Local ; NameOfSpace Hcurl_A ; }
                { Name Khi  ; Type Local ; NameOfSpace Hregion_khi_3D ; }
                { Name Psi  ; Type Local ; NameOfSpace Hregion_psi_3D ; }
            }
        
            Equation {
                Galerkin { [ (({d Psi} /\ Dof{d Khi}) /\ {d Psi}) , {d Khi}] ;
                    In RegionComp ; Jacobian Vol ; Integration GaussInt ; }
                Galerkin { [  -({d A} /\ {d Psi}), {d Khi}] ;
                    In RegionComp ; Jacobian Vol ; Integration GaussInt ; }  // computes Khi(n+1) from  from Psi(n+1) and A
            }
        }
}

Resolution {
    { Name Main_System ;
        System {
            { Name SysT; NameOfFormulation T_projection; }
            { Name SysA; NameOfFormulation A_formalism;}
            // { Name SysPsi; NameOfFormulation Psi_formalism; }
            // { Name SysKhi; NameOfFormulation Khi_formalism; }
        }
        Operation {       
            CreateDir[Dir] ;

            

            Generate[SysT] ;
            PostOperation[Gmsh_J] ;
            Solve[SysT] ;
            SaveSolution[SysT] ;
            PostOperation[Gmsh_T] ;

            SetGlobalSolverOptions ["-ksp_type gmres -ksp_gmres_restart 300 -pc_type icc"];
            Generate[SysA] ; 
            Solve[SysA] ;
            SaveSolution[SysA] ;
            PostOperation[Gmsh_A] ;

            
            // InitSolution[SysKhi];

            // SaveSolution[SysKhi] ;
            // //PostOperation[Gmsh_Khi_init] ;

            // If(flag_iter_loop==1)
            //     IterativeLoop[max_iter, eps_diff, relax_factor] {
            //     GenerateJac[SysPsi]; SolveJac[SysPsi];
            //     Generate[SysKhi]; Solve[SysKhi];
            //     }
            //     SaveSolution[SysPsi]; 
            //     SaveSolution[SysKhi];
            // EndIf

            // If(flag_iter_loop==0)
            //     For i In {1:max_iter}
            //     Generate[SysPsi]; Solve[SysPsi]; SaveSolution[SysPsi]; 
            //     Generate[SysKhi]; Solve[SysKhi]; SaveSolution[SysKhi];
            //     PostOperation[Gmsh_Error] ;
            //     EndFor
                
            // EndIf
            
            // PostOperation[Gmsh_Psi];
            // PostOperation[Gmsh_Khi];

            }
    }    
}
  
PostProcessing {
    { Name J_Post ; NameOfFormulation T_projection;
        PostQuantity {
            { Name j_all; Value { Term { [ CurrentDensity[]] ; In CurrentRegion; Jacobian Vol; } } }
            { Name jz_all; Value { Term { [ CompZ[CurrentDensity[]]] ; In CurrentRegion; Jacobian Vol; } } }
            { Name jphi_all; Value { Term { [-CompX[CurrentDensity[]]*Sin[Atan2[Y[], X[]]#2]+CompY[CurrentDensity[]]*Cos[#2]] ; In CurrentRegion; Jacobian Vol; } } }
            { Name jr_all; Value { Term { [CompX[CurrentDensity[]]*Cos[Atan2[Y[], X[]]#3]+CompY[CurrentDensity[]]*Sin[#3]] ; In CurrentRegion; Jacobian Vol; } } }
        }
    }
    { Name T_Post ; NameOfFormulation T_projection;
        PostQuantity {
            { Name j; Value { Term { [ {d T}] ; In RegionComp; Jacobian Vol; } } }
            { Name jz; Value { Term { [ CompZ[{d T}]] ; In RegionComp; Jacobian Vol; } } }
            { Name jphi; Value { Term { [-CompX[{d T}]*Sin[Atan2[Y[], X[]]#2]+CompY[{d T}]*Cos[#2]] ; In RegionComp; Jacobian Vol; } } }
            { Name jr; Value { Term { [CompX[{d T}]*Cos[Atan2[Y[], X[]]#3]+CompY[{d T}]*Sin[#3]] ; In RegionComp; Jacobian Vol; } } }
        }
    }
    { Name A_Post ; NameOfFormulation A_formalism;
        PostQuantity {
            { Name b; Value { Term { [ {d A}] ; In RegionComp; Jacobian Vol; } } }
        }
    }
    { Name Psi_Post ; NameOfFormulation Psi_formalism;
        PostQuantity {
            { Name psi; Value { Term { [ {Psi}] ; In RegionComp; Jacobian Vol; } } }
        }
    }
    { Name Khi_Post ; NameOfFormulation Khi_formalism;
        PostQuantity {
            { Name khi; Value { Term { [ {Khi}] ; In RegionComp; Jacobian Vol; } } }
        }
    }
}

// *Customize output on Gmsh interface*
PostOperation Gmsh_T UsingPost T_Post {
    ExtGmsh     = ".pos";
    Print[ j, OnElementsOf RegionComp, File StrCat[Dir,"J",ExtGmsh], LastTimeStepOnly ] ;
    Print[ jphi, OnElementsOf RegionComp, File StrCat["jphi",ExtGmsh], LastTimeStepOnly ] ;
    Print[ jr, OnElementsOf RegionComp, File StrCat["jr",ExtGmsh], LastTimeStepOnly ] ;
    Print[ jz, OnElementsOf RegionComp, File StrCat["jz",ExtGmsh], LastTimeStepOnly ] ;
}

PostOperation Gmsh_J UsingPost J_Post {
    ExtGmsh     = ".pos";
    Print[ j_all, OnElementsOf CurrentRegion, File StrCat[Dir,"J_all",ExtGmsh], LastTimeStepOnly ] ;
    Print[ jphi_all, OnElementsOf CurrentRegion, File StrCat["jphi_all",ExtGmsh], LastTimeStepOnly ] ;
    Print[ jr_all, OnElementsOf CurrentRegion, File StrCat["jr_all",ExtGmsh], LastTimeStepOnly ] ;
    Print[ jz_all, OnElementsOf CurrentRegion, File StrCat["jz_all",ExtGmsh], LastTimeStepOnly ] ;
}

    PostOperation Gmsh_A UsingPost A_Post {
    ExtGmsh     = ".pos";
    Print[ b, OnElementsOf RegionComp, File StrCat[Dir,"B",ExtGmsh], LastTimeStepOnly ] ;
}

PostOperation Gmsh_Psi UsingPost Psi_Post {
    ExtGmsh     = ".pos";
    Print[ psi, OnElementsOf RegionComp, File StrCat[Dir,"Psi",ExtGmsh], LastTimeStepOnly ] ;
} 

PostOperation Gmsh_Khi UsingPost Khi_Post {
    ExtGmsh     = ".pos";
    Print[ khi, OnElementsOf RegionComp, File StrCat[Dir,"Khi",ExtGmsh], LastTimeStepOnly ] ;
}

    
    
    DefineConstant[
        R_ = {"Main_System", Name "GetDP/1ResolutionChoices", Visible 0},
        C_ = {"-solve -v2", Name "GetDP/9ComputeCommand", Visible 0}
        P_ = {"", Name "GetDP/2PostOperationChoices", Visible 0}
    ];