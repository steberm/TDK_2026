clc
%This code is for the reading of the MSH4.1 file generated automatically
% by gmsh

%Input: A [filename].msh file that is MSH4.1 format
%Outputs: 
%   -All nodes in the whole geometry (new IDs)
%   -Ry: the rotation matrix of the periodic surfaces
%__________________________________________________________________

dir = 'C:\__BME\__Dawn Raider\plasma\Geometry\';
filename = 'geo_merge.msh';

maxElementLenght=10;

%__________________________________________________________________
physicalNames = struct( ...
    'dim', {}, ...
    'tag', {}, ...
    'name', {} );

pointEntities = struct( ...
    'tag', {}, ...
    'X', {}, ...
    'Y', {}, ...
    'Z', {}, ...
    'numPhysicalTags', {}, ...
    'physicalTags', {} );

curveEntities = struct( ...
    'tag', {}, ...
    'minX', {}, ...
    'minY', {}, ...
    'minZ', {}, ...
    'maxX', {}, ...
    'maxY', {}, ...
    'maxZ', {}, ...
    'numPhysicalTags', {}, ...
    'physicalTags', {}, ...
    'numBoundingPoints', {}, ...
    'boundingPoints', {} );

surfaceEntities = struct( ...
    'tag', {}, ...
    'minX', {}, ...
    'minY', {}, ...
    'minZ', {}, ...
    'maxX', {}, ...
    'maxY', {}, ...
    'maxZ', {}, ...
    'numPhysicalTags', {}, ...
    'physicalTags', {}, ...
    'numBoundingCurves', {}, ...
    'boundingCurves', {} );

volumeEntities = struct( ...
    'tag', {}, ...
    'minX', {}, ...
    'minY', {}, ...
    'minZ', {}, ...
    'maxX', {}, ...
    'maxY', {}, ...
    'maxZ', {}, ...
    'numPhysicalTags', {}, ...
    'physicalTags', {}, ...
    'numBoundingSurfaces', {}, ...
    'boundingSurfaces', {} );



%Nodes beolvasása egy MSH 4.1 típusú file-ból


fid = fopen( strcat(dir, filename), 'r');


% Reading Physical Names
while true
    line = fgetl(fid);
    
    if ~ischar(line)      % fájl vége
        break
    end
    
    if strcmp(line, "$PhysicalNames")   % ha elérjük a keresett sort
        break
    end
end

line = fgetl(fid);
data = sscanf(line, '%f');
numPhysical = data(1);

for i = 1:numPhysical

    line = strtrim(fgetl(fid));
    data = textscan(line, '%d %d %q');

    physicalNames(i).dim  = data{1};
    physicalNames(i).tag  = data{2};
    physicalNames(i).name = data{3}{1};
end


% Reading Entities
while true
    line = fgetl(fid);
    
    if ~ischar(line)      % fájl vége
        break
    end
    
    if strcmp(line, "$Entities")   % ha elérjük a keresett sort
        break
    end
end


line = fgetl(fid);
data = sscanf(line, '%f');
numPent = data(1);
numCent = data(2);
numSent = data(3);
numVent = data(4);

for i = 1:numPent

    line = fgetl(fid);
    data = sscanf(line, '%f');

    pointEntities(i).tag = data(1);

    pointEntities(i).X = data(2);
    pointEntities(i).Y = data(3);
    pointEntities(i).Z = data(4);
    
    numPhysicalTags = data(5);
    pointEntities(i).numPhysicalTags=numPhysicalTags;

    pointEntities(i).physicalTags = data(6 : 5 + numPhysicalTags);
end

for i = 1:numCent

    line = fgetl(fid);
    data = sscanf(line, '%f');

    % Basic data
    curveEntities(i).tag = data(1);

    curveEntities(i).minX = data(2);
    curveEntities(i).minY = data(3);
    curveEntities(i).minZ = data(4);

    curveEntities(i).maxX = data(5);
    curveEntities(i).maxY = data(6);
    curveEntities(i).maxZ = data(7);

    % Physical tags
    numPhysicalTags = data(8);
    curveEntities(i).numPhysicalTags=numPhysicalTags;

    physStart = 9;
    physEnd   = physStart + numPhysicalTags - 1;

    curveEntities(i).physicalTags = data(physStart : physEnd);

    % Bounding points
    numBoundingPoints = data(physEnd + 1);
    curveEntities(i).numBoundingPoints = numBoundingPoints;
    boundStart = physEnd + 2;
    boundEnd   = boundStart + numBoundingPoints - 1;

    curveEntities(i).boundingPoints = data(boundStart : boundEnd);
end

for i = 1:numSent

    line = fgetl(fid);
    data = sscanf(line, '%f');

    % Basic data
    surfaceEntities(i).tag = data(1);

    surfaceEntities(i).minX = data(2);
    surfaceEntities(i).minY = data(3);
    surfaceEntities(i).minZ = data(4);

    surfaceEntities(i).maxX = data(5);
    surfaceEntities(i).maxY = data(6);
    surfaceEntities(i).maxZ = data(7);

    % Physical tags
    numPhysicalTags = data(8);
    surfaceEntities(i).numPhysicalTags=numPhysicalTags;

    physStart = 9;
    physEnd   = physStart + numPhysicalTags - 1;

    surfaceEntities(i).physicalTags = data(physStart : physEnd);

    % Bounding curves
    numBoundingCurves = data(physEnd + 1);
    surfaceEntities(i).numBoundingCurves = numBoundingCurves;
    boundStart = physEnd + 2;
    boundEnd   = boundStart + numBoundingCurves - 1;

    surfaceEntities(i).boundingCurves = data(boundStart : boundEnd);
end

for i = 1:numVent

    line = fgetl(fid);
    data = sscanf(line, '%f');

    % Basic data
    volumeEntities(i).tag = data(1);

    volumeEntities(i).minX = data(2);
    volumeEntities(i).minY = data(3);
    volumeEntities(i).minZ = data(4);

    volumeEntities(i).maxX = data(5);
    volumeEntities(i).maxY = data(6);
    volumeEntities(i).maxZ = data(7);

    % Physical tags
    numPhysicalTags = data(8);
    volumeEntities(i).numPhysicalTags=numPhysicalTags;

    physStart = 9;
    physEnd   = physStart + numPhysicalTags - 1;

    volumeEntities(i).physicalTags = data(physStart : physEnd);

    % Bounding surfaces
    numBoundingSurfaces = data(physEnd + 1);
    volumeEntities(i).numBoundingSurfaces = numBoundingSurfaces;

    boundStart = physEnd + 2;
    boundEnd   = boundStart + numBoundingSurfaces - 1;

    volumeEntities(i).boundingSurfaces = data(boundStart : boundEnd);
end


% Reading Nodes
while true
    line = fgetl(fid);
    
    if ~ischar(line)      % fájl vége
        break
    end
    
    if strcmp(line, "$Nodes")   % ha elérjük a keresett sort
        break
    end
end
line = fgetl(fid);
data = sscanf(line, '%f');
numEntities = data(1);
numNodes = data(2);
maxNodeId = data(4);

allNodes=zeros(numNodes,6); %entDim entID id x y z
allNode2idx = zeros(maxNodeId, 1);
anchor=1;
for i = 1:numEntities
    line = fgetl(fid);
    data = sscanf(line, '%f');
    numNodesInBlock=data(4);
    entityTag = data(2);
    entityDim = data(1);
    for j=anchor:anchor+numNodesInBlock-1 %Writing the IDs
        line = fgetl(fid);
        data = sscanf(line, '%f');
        allNodes(j,3) = data(1);
        allNodes(j,2) = entityTag;
        allNodes(j,1) = entityDim;
        allNode2idx(data(1)) = j;
    end
    for j=anchor:anchor+numNodesInBlock-1 %Writing the coords
        line = fgetl(fid);
        data = sscanf(line, '%f');
        allNodes(j,4:6)=data(1:3);
    end
    anchor = anchor + numNodesInBlock; % Update anchor for the next block
end
nodeEntity=length( unique(allNodes(:,1:2), 'rows'));

% Reading Elements
while true
    line = fgetl(fid);
    
    if ~ischar(line)      % fájl vége
        break
    end
    
    if strcmp(line, "$Elements")   % ha elérjük a keresett sort
        break
    end
end
line = fgetl(fid);
data = sscanf(line, '%f');
numEntities = data(1);
numElements = data(2);
elemEntity = numEntities;
maxElementId = data(4);

allTris=zeros(round(numElements/2),6,'uint32'); %entDim entID id n1 n2 n3
allTets=zeros(numElements,7,'uint32'); %entDim entID id n1 n2 n3 n4
allElems=zeros(round(numElements/10),4+maxElementLenght,'uint32'); %entDim entID elemType id n1 n2 n3 n4...
longestElem=1;

allNode2tris = cell(numNodes,1);
allNode2tets = cell(numNodes,1);
allNode2elems = cell(numNodes,1);

elements2idx = zeros(maxElementId,2); %elementType idx

triAnchor=1;
tetAnchor=1;
elemsAnchor=1;

for i = 1:numEntities
    line = fgetl(fid);
    data = sscanf(line, '%f');
    numElementsInBlock=data(4);
    entityDim = data(1);
    entityTag = data(2);
    elementType = data(3);
    if numElementsInBlock~=0
        if elementType==2
            for j=triAnchor:triAnchor+numElementsInBlock-1
                line = fgetl(fid);
                data = sscanf(line, '%f');
                allTris(j,1)=entityDim;
                allTris(j,2)=entityTag;
                allTris(j,3)=data(1);
                allTris(j,4:6)=data(2:4);
                for k = 1:length(data)-1                
                    allNode2tris{data(k+1)}(end+1) = j;
                end
                elements2idx(data(1),:)=[2,j];
            end
            triAnchor = triAnchor + numElementsInBlock; % Update anchor for the next block

        elseif elementType==4
            for j=tetAnchor:tetAnchor+numElementsInBlock-1
                line = fgetl(fid);
                data = sscanf(line, '%f');
                allTets(j,1)=entityDim;
                allTets(j,2)=entityTag;
                allTets(j,3)=data(1);
                allTets(j,4:7)=data(2:5);
                for k = 1:length(data)-1                
                    allNode2tets{data(k+1)}(end+1) = j; %tets(node2tets{1},:) to get all tets with nodeID=1 in them
                end
                elements2idx(data(1),:)=[4,j];
            end
            tetAnchor = tetAnchor + numElementsInBlock; % Update anchor for the next block

        else
            for j=elemsAnchor:elemsAnchor+numElementsInBlock-1
                line = fgetl(fid);
                data = sscanf(line, '%f');
                allElems(j,1)=entityDim;
                allElems(j,2)=entityTag;
                allElems(j,3)=elementType;
                allElems(j,4)=data(1);
                allElems(j,5:length(data)+3)=data(2:length(data));
                if longestElem<length(data)+3
                    longestElem=length(data)+3;
                end
                for k = 1:length(data)-1                
                    allNode2elems{data(k+1)}(end+1) = j;
                end
                elements2idx(data(1),:)=[1,j];
            end
            elemsAnchor = elemsAnchor + numElementsInBlock; % Update anchor for the next block
        end
    end
end
allElems(elemsAnchor:end,:)=[]; %other elements
allElems(:,longestElem+1:end)=[];
allTris(triAnchor:end,:)=[];
allTets(tetAnchor:end,:)=[];




clear boundEnd boundStart data fid i j k line numPhysicalTags physStart physEnd anchor entityTag
clear numNodesInBlock elementType maxElementLenght elemsAnchor triAnchor tetAnchor
clear numBoundingSurfaces numBoundingCurves numBoundingPoints numElementsInBlock longestElem entityDim