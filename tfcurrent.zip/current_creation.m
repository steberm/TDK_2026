clc

if ~exist( 'writeMerged' ,"var")
    writeMerged = false;
end

flagWrite = 1;
CrossSection = 4.9804254e+05/1e6;
Current = 9.11e6;
deps = 87; %ennyi fokot kell legalább bezárniuk, hogy merőlegesnek vegyem
TFTetsGlobal = [];
TFJGlobal = [];
for itf=1:2
    %finding the the TF physical tag
    for i=1:numPhysical
        if strcmp(physicalNames(i).name, strcat("TF", int2str(itf)))
            TFPhysicalTag = physicalNames(i).tag;
        end
    end
    
    %finding the the TF volume enity
    for i=1:numVent
        if volumeEntities(i).physicalTags(1)==TFPhysicalTag(1)
            TFVolEntTag = volumeEntities(i).tag;
        end
    end

    TFTets = zeros(size(allTets/3,1),5);
    TetsCoords = zeros(size(allTets/3,1),3);
    anchor = 1;
    for i=1:size(allTets,1) %entDim entID id n1 n2 n3 n4
        if allTets(i,2)==TFVolEntTag && allTets(i,1)==3
            TFTets(anchor,:) = allTets(i,3:7);

            x=zeros(4,1);
            y=zeros(4,1);
            z=zeros(4,1);

            for j=1:4
                n = allNode2idx(TFTets(anchor,j+1)); %node index
                x(j) = allNodes(n,4);
                y(j) = allNodes(n,5);
                z(j) = allNodes(n,6);
            end
            
            TetsCoords(anchor,1) = sum(x)/4;
            TetsCoords(anchor,2) = sum(y)/4;
            TetsCoords(anchor,3) = sum(z)/4;
            anchor = anchor+1;
        end
    end
    %finished all volume elements and coords
    TFTets(anchor:end,:)=[];
    TetsCoords(anchor:end,:)=[];
    


    %Creating the triangles from the tetrahedrons
    
    % TFTets(:,2:5) contains node IDs of tetrahedra
    tets = TFTets(:,2:5);
    
    % All 4 faces of a tetrahedron (node index patterns)
    faces_local = [
        1 2 3
        1 2 4
        1 3 4
        2 3 4
    ];
    
    % Preallocate
    N = size(tets,1);
    all_faces = zeros(N*4, 3);
    
    % Generate all triangle faces
    for k = 1:4
        rows = (k-1)*N + (1:N);
        all_faces(rows,:) = tets(:, faces_local(k,:));
    end
    
    % Sort node IDs in each triangle (so [1 2 3] == [3 2 1])
    all_faces = sort(all_faces, 2);
    
    
    %Convert the list of faces into "unique faces + how often they appear" then keep only those that appear once
    [unique_faces, ~, ic] = unique(all_faces, 'rows');
    counts = accumarray(ic, 1);
    
    TFSurfaceTri = unique_faces(counts == 1, :);

    clear k x y z rows

    %______________________________________________________________________
    %Getting the normal vector of all surface elements
    Ns = size(TFSurfaceTri,1);

    tri2tet = zeros(Ns,1);
    
    for i = 1:Ns
        tri = TFSurfaceTri(i,:);
    
        % logikai mátrix: mely tetra-k tartalmazzák a node-okat
        match = ismember(tets, tri);   % [Nt x 4] logical
    
        % megszámoljuk soronként a találatokat
        counts = sum(match, 2);        % [Nt x 1]
    
        % ahol 3 egyezés van → az a tetra
        idx = find(counts == 3);
    
        if isempty(idx)
            error('Triangle %d nem található tetra-ban.', i);
        elseif numel(idx) > 1
            warning('Triangle %d több tetra-ban is szerepel.', i);
        end
    
        tri2tet(i) = idx(1);
    end
    
    
    
    % Surface trigs normals facing outwards
    
    TFOrientedTri = TFSurfaceTri;
    TFSurfaceNormal = zeros(size(TFOrientedTri,1),3); %x y z
    SurfaceCoords = zeros(size(TFOrientedTri,1),3); % x y z
    
    for i = 1:Ns
        tri = TFSurfaceTri(i,:);   % [a b c]
        tet = tets(tri2tet(i),:);       % [n1 n2 n3 n4]
    
        % Acquiring the 4. node
        d = tet(~ismember(tet, tri));
        
        % Acquiring the coordinates of nodes
        A = allNodes(allNode2idx(tri(1)), 4:6);
        B = allNodes(allNode2idx(tri(2)), 4:6);
        C = allNodes(allNode2idx(tri(3)), 4:6);
        D = allNodes(allNode2idx(d),      4:6);
    
        % Defining the normal
        n = cross(B - A, C - A);
    
        % Checking orientation
        v = D - A;
        
        if dot(n, v) > 0 %points inwards
            % flip
            TFOrientedTri(i,:) = [tri(1), tri(3), tri(2)];
        end
        A = allNodes(allNode2idx(TFOrientedTri(i,1)), 4:6);
        B = allNodes(allNode2idx(TFOrientedTri(i,2)), 4:6);
        C = allNodes(allNode2idx(TFOrientedTri(i,3)), 4:6);
        SurfaceCoords(i,:) = (A+B+C)/3;
        TFSurfaceNormal(i,:) = cross(B - A, C - A)/norm(cross(B - A, C - A));
    end

    idx = SurfaceCoords(:,3) < 0.6 & ...
      SurfaceCoords(:,3) > -0.6 & ...
      abs(TFSurfaceNormal(:,3)) > 0.5;

    TFOrientedTri(idx,:) = [];
    SurfaceCoords(idx,:) = [];
    TFSurfaceNormal(idx,:) = [];
    
    clear d counts idx n nodeIDs Ns Nt tet tri v match
    


    %_____________________Creating Current vectors______________________
    TFJ = zeros(size(TFTets,1),3); %x y z
    idx = knnsearch(SurfaceCoords, TetsCoords(:,:), 'K', round(size(SurfaceCoords,1)/10));
    for i=1:size(TFTets,1)
        n1 = TFSurfaceNormal(idx(i,1),:);
        j=2;
        while 1
            n2 = TFSurfaceNormal(idx(i,j),:);
            if(abs(dot(n1,n2))<cosd(deps) && norm(n2)~=0)
                TFJ(i,:) = cross(n1,n2);
                TFJ(i,:) = TFJ(i,:)/norm(TFJ(i,:));
                if TFJ(i,:) == zeros(1,3)
                    disp 'Null vector given'
                end
                break;
            end
            if j == size(idx,2)
                disp 'No suitable orthogonal nodes found'
                TFJ(i,:) = zeros(1,3);
                break;
            end
            j=j+1;
        end
    
        
    end

    %_____________________Determening the axis of TF____________________
    com = sum(TetsCoords)/length(TetsCoords);
    sumdir = [0,0,0];

    for i=1:length(TFSurfaceNormal)
        if dot(com, TFSurfaceNormal(i,:))/norm(com)/norm(TFSurfaceNormal(i,:)) < cosd(deps)
            crossprod=cross(com, TFSurfaceNormal(i,:));
            if crossprod(3)>0
                sumdir=sumdir+TFSurfaceNormal(i,:);
            else
                sumdir=sumdir-TFSurfaceNormal(i,:);
            end
        end
    end

    %_____________________Flipping J into direction____________________
    for i=1:length(TFTets)
        locVec = cross(sumdir, TFJ(i,:));
        locDir = com-TetsCoords(i,:);
        if dot(locDir, locVec) > 0
            TFJ(i,:) = -1* TFJ(i,:);
        end
    end
    


    TFTetsGlobal = [TFTetsGlobal; TFTets(:,1)]; 
    TFJGlobal = [TFJGlobal; TFJ];


%__________________________________________________________________________
end
% Scaling current desity
TFJGlobal = TFJGlobal*Current/CrossSection;
%__________________________________________________________________________
if flagWrite
    [filepath, name, ext] = fileparts(filename);
    copyFilename = [name, '_TFJ', ext];
    
    copyfile(strcat(dir, filename), strcat(dir, copyFilename), 'f');
    if writeMerged == false

        fid = fopen( strcat(dir, copyFilename), 'a');
    
        fprintf(fid, strcat('$ElementData\n','1\n','"J_TF"\n', '1\n', '0\n'));
        fprintf(fid, strcat('4\n', '0\n', '3\n', int2str(length(TFTetsGlobal)), '\n0\n'));
        
        for i=1:length(TFJGlobal)
            fprintf(fid, '%d %f %f %f\n', TFTetsGlobal(i), TFJGlobal(i,1), TFJGlobal(i,2), TFJGlobal(i,3));
        end
        
        
        fprintf(fid, '$EndElementData\n');
        
    
        fclose(fid);

    end
end



clear counts N unique_faces ic all_faces faces_local


disp 'Done'