SetFactory("OpenCASCADE");

Include "C:\__BME\__Dawn Raider\plasma\GetDP\model_params.pro";



air = 1000; //tag of the air region


Merge "ITER_40DEG_5.stp";

Recursive Delete { Volume{1:48}; }

Merge "ITER_40DEG.stp";

Recursive Delete { Volume{84:96}; }
Recursive Delete { Curve{2934:2941, 4655:4662}; }


vessel[] = Volume{:};


Sphere(air) = {0,0,0, BndRadius, -0.5*Pi, 0.5*Pi, alpha};

inter = BooleanIntersection{ Volume{vessel[]}; Delete; }{ Volume{air}; };

Dilate {{0,0,0}, 0.001} {
    Volume{:};
}

Coherence;

Physical Volume("TF1", 101) = {62};
Physical Volume("TF2", 102) = {63};

Physical Volume("CS1", 301) = {49};
Physical Volume("CS2", 302) = {50};
Physical Volume("CS3", 303) = {51};
Physical Volume("CS4", 304) = {52};
Physical Volume("CS5", 305) = {53};
Physical Volume("CS6", 306) = {54};

Physical Volume("PF1", 401) = {60};
Physical Volume("PF2", 402) = {58};
Physical Volume("PF3", 403) = {56};
Physical Volume("PF4", 404) = {57};
Physical Volume("PF5", 405) = {59};
Physical Volume("PF6", 406) = {55};

Coils[] = {62, 63, 49:60};

VacuumVessel[] = {64:83};
Physical Volume("VacuumVessel", 201) = VacuumVessel[];

Admissible = 61;
Physical Volume("Admissible", 501) = Admissible;

Air = 84;
Physical Volume("Air", 601) = Air;

Physical Volume("Computational", 701) = {Coils[], Admissible, VacuumVessel[], Air}; //Full computational region




Physical Surface("AdmissibleBoundary", 1401) = {2167:2349};
Physical Surface("Boundary", 1301) = {2722};
CS0[]= {2097, 2103, 2109, 2115, 2121, 2127};
CS40[]= {2099, 2105, 2111, 2117, 2123, 2129};

PF0[] = {2163, 2151, 2139, 2144, 2157, 2133};
PF40[] = {2165, 2153, 2141, 2146, 2159, 2135};

Air0 = 2724;
Air40 = 2723;

Admis0 = 2168;
Admis40 = 2170;

Physical Surface("Per1_admissible", 1201) = {Admis0};
Physical Surface("Per2_admissible", 1202) = {Admis40};

VV_l_out0[] = {2618, 2712, 2581};
VV_l_out40[] = {2632, 2714, 2569};

VV_l_in0[] = {2504, 2556, 2413};
VV_l_in40[] = {2514, 2552, 2406};

VV_t_out0[] = {2620, 2704, 2609};
VV_t_out40[] = {2636, 2707, 2648};

VV_t_in0[] = {2499, 2549, 2427};
VV_t_in40[] = {2512, 2546, 2471};

VV_b_out0[] = {2605, 2715, 2576};
VV_b_out40[] = {2645, 2713, 2564};

VV_b_in0[] = {2423, 2550, 2420};
VV_b_in40[] = {2475, 2551, 2399};

phi0[] = {CS0[], PF0[], Air0, Admis0, VV_l_out0[], VV_l_in0[], VV_t_out0[], VV_t_in0[], VV_b_out0[], VV_b_in0[]};
phi40[] = {CS40[], PF40[], Air40, Admis40, VV_l_out40[], VV_l_in40[], VV_t_out40[], VV_t_in40[], VV_b_out40[], VV_b_in40[]};

Physical Surface("Per1_whole", 1101) = {phi0[]};
Physical Surface("Per2_whole", 1102) = {phi40[]};

Periodic Surface {phi40[]} = {phi0[]} Rotate { { 0,0,1 }, { 0,0,0 }, alpha};

Printf("phi0 surfaces: %g", #phi0[]);
Printf("phi40 surfaces: %g", #phi40[]);


Mesh.MeshSizeFromCurvature = 10;
Mesh.MeshSizeMin = 0.002;
Mesh.MeshSizeMax = 8;

Field[1] = Distance;
Field[1].SurfacesList = {Boundary{ Volume{Coils[]}; }};
Field[1].Sampling = 10;

Field[2] = Distance;
Field[2].SurfacesList = {Boundary{ Volume{VacuumVessel[]}; }};
Field[2].Sampling = 10;

Field[3] = Distance;
Field[3].SurfacesList = {Boundary{ Volume{Admissible}; }}; //Admissible
Field[3].Sampling = 10;

Field[4] = MathEval;
Field[4].F = StrCat(mshScale, "*", v); //Vacuum Vessel volume mesh

Field[5] = MathEval;
Field[5].F = StrCat(mshScale, "*", a); //Admissible volume mesh

Field[6] = MathEval;
Field[6].F = StrCat(mshScale, "*(", c, " + (", M, "-", c, ")*Min(1,F1/", D, ")^1.5)"); //Coil distance based default mesh

Field[7] = MathEval;
Field[7].F = StrCat(mshScale, "*(", v, " + (", M, "-", v, ")*Min(1,F2/", d, ")^3)"); //Vacuum vessel based support mesh

Field[8] = MathEval;
Field[8].F = StrCat(mshScale, "*(", a, " + (", M, "-", a, ")*Min(1,F3/", d, ")^3)"); //Admissible based support mesh

Field[9] = Restrict;
Field[9].InField = 4;
Field[9].VolumesList = {VacuumVessel[]};

Field[10] = Restrict;
Field[10].InField = 5;
Field[10].VolumesList = {Admissible};

Field[11] = Min;
Field[11].FieldsList = {6:10};

Background Field = 11;

Mesh 3;